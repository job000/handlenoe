import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../models/shopping_list_model.dart';
import '../models/shopping_item_model.dart';
import '../services/shopping_service.dart';

final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin =
    FlutterLocalNotificationsPlugin();

class ShoppingListProvider with ChangeNotifier {
  final ShoppingService _shoppingService = ShoppingService();
  List<ShoppingList> _shoppingLists = [];
  bool _notificationsEnabled = false;

  List<ShoppingList> get shoppingLists => _shoppingLists;
  bool get notificationsEnabled => _notificationsEnabled;

  Future<void> fetchShoppingLists(String userId) async {
    _shoppingLists = await _shoppingService.getShoppingLists(userId);
    for (var list in _shoppingLists) {
      list.items = await _shoppingService.getItemsForList(list.id);
    }
    notifyListeners();
  }

  Stream<List<ShoppingList>> getShoppingListsStream(String userId) {
    return _shoppingService.getShoppingListsStream(userId);
  }

  Stream<QuerySnapshot> getItemsForListStream(String listId) {
    return _shoppingService.getItemsForListStream(listId);
  }

  Future<void> addShoppingList(ShoppingList list) async {
    await _shoppingService.addShoppingList(list);
    notifyListeners();
  }

  Future<void> updateShoppingList(ShoppingList list) async {
    await _shoppingService.updateShoppingList(list);
    notifyListeners();
  }

  Future<void> deleteShoppingList(String listId) async {
    await _shoppingService.deleteShoppingList(listId);
    notifyListeners();
  }

  Future<void> addItemToList(String listId, ShoppingItem item) async {
    final currentUser = FirebaseAuth.instance.currentUser;
    if (currentUser == null) return;

    await _shoppingService.addItemToList(listId, item);
    notifyListeners();

    // Find the list and notify other users
    try {
      final list = _shoppingLists.firstWhere((list) => list.id == listId);
      final allUsers = [list.owner, ...list.sharedWith];
      final otherUsers = allUsers.where((user) => user != currentUser.uid).toList();

      for (var userId in otherUsers) {
        // Get notification settings for each user
        _shoppingService.getNotificationSettings(userId, listId).listen((settings) async {
          if (settings.notificationsEnabled) {
            await _sendNotification('New Item Added', 'An item was added to your list.');
          }
        });
      }
    } catch (e) {
      debugPrint('List not found: $e');
    }
  }

  Future<void> updateItemInList(String listId, ShoppingItem item) async {
    await _shoppingService.updateItemInList(listId, item);
    notifyListeners();
  }

  Future<void> deleteItemFromList(String listId, String itemId) async {
    await _shoppingService.deleteItemFromList(listId, itemId);
    notifyListeners();
  }

  Future<void> shareListWithUserByEmail(String listId, String email) async {
    await _shoppingService.shareListWithUserByEmail(listId, email);
    notifyListeners();
  }

  Future<void> toggleNotifications(String userId, String listId, bool enable) async {
    await _shoppingService.toggleNotifications(userId, listId, enable);
    notifyListeners();
  }

  Future<void> toggleAllNotifications(String userId, bool enable) async {
    for (var list in _shoppingLists) {
      await _shoppingService.toggleNotifications(userId, list.id, enable);
    }
    _notificationsEnabled = enable;
    notifyListeners();
  }

  bool notificationsEnabledForList(String listId) {
    final list = _shoppingLists.firstWhere(
      (list) => list.id == listId,
      orElse: () => ShoppingList(
        id: '',
        name: '',
        owner: '',
        ownerEmail: '',
        items: [],
        sharedWith: [],
        notificationsEnabled: false,
      ),
    );
    return list.notificationsEnabled;
  }

  Future<void> _sendNotification(String title, String body) async {
    const AndroidNotificationDetails androidPlatformChannelSpecifics =
        AndroidNotificationDetails(
      'your_channel_id',
      'your_channel_name',
      channelDescription: 'your_channel_description',
      importance: Importance.max,
      priority: Priority.high,
      showWhen: false,
    );
    const NotificationDetails platformChannelSpecifics =
        NotificationDetails(android: androidPlatformChannelSpecifics);
    await flutterLocalNotificationsPlugin.show(
      0, // Use an int for the notification ID
      title,
      body,
      platformChannelSpecifics,
      payload: 'item x',
    );
  }
}
