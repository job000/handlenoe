// ignore_for_file: avoid_print

import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class FirebaseMessagingService {
  final FirebaseMessaging _firebaseMessaging = FirebaseMessaging.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<void> initialize() async {
    // Request permissions for iOS
    NotificationSettings settings = await _firebaseMessaging.requestPermission(
      alert: true,
      announcement: false,
      badge: true,
      carPlay: false,
      criticalAlert: false,
      provisional: false,
      sound: true,
    );

    if (settings.authorizationStatus == AuthorizationStatus.authorized) {
      print('User granted permission');
    } else if (settings.authorizationStatus == AuthorizationStatus.provisional) {
      print('User granted provisional permission');
    } else {
      print('User declined or has not accepted permission');
    }

    // Get the token each time the application loads
    String? token = await _firebaseMessaging.getToken();
    print("FCM Token: $token");

    // Save token to Firestore
    await saveTokenToFirestore(token);

    // Handle incoming messages
    FirebaseMessaging.onMessage.listen((RemoteMessage message) async {
      print('Got a message whilst in the foreground!');
      print('Message data: ${message.data}');

      if (message.notification != null) {
        print('Message also contained a notification: ${message.notification}');
      }

      // Check user-specific notification settings
      bool shouldNotify = await shouldNotifyUser(message);
      if (shouldNotify) {
        // Display notification (handle as per your app logic)
        print("Notified.");
      }
    });

    FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) {
      print('Message clicked!');
    });
  }

  Future<void> saveTokenToFirestore(String? token) async {
    if (token == null) return;

    User? user = FirebaseAuth.instance.currentUser;
    if (user == null) {
      print('User not authenticated');
      return;
    }

    String userId = user.uid;

    await _firestore.collection('users').doc(userId).update({
      'fcmToken': token,
    });
  }

  Future<bool> shouldNotifyUser(RemoteMessage message) async {
    User? user = FirebaseAuth.instance.currentUser;
    if (user == null) {
      print('User not authenticated');
      return false;
    }

    String userId = user.uid;
    String listId = message.data['listId']; // Assuming listId is sent in the message data

    DocumentSnapshot listSnapshot = await _firestore.collection('shoppingLists').doc(listId).get();

    if (!listSnapshot.exists) return false;

    Map<String, dynamic> listData = listSnapshot.data() as Map<String, dynamic>;

    // Check if the user is the owner or a shared user and return their notification setting
    if (listData['owner'] == userId) {
      return listData['ownerNotificationsEnabled'] ?? false;
    } else if (listData['sharedWith'] != null && listData['sharedWith'].containsKey(userId)) {
      return listData['sharedWith'][userId] ?? false;
    } else {
      return false;
    }
  }
}

Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  print('Handling a background message: ${message.messageId}');
  // Implement background message handling logic
}
