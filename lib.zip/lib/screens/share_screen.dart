import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/shopping_list_provider.dart';

class ShareScreen extends StatefulWidget {
  final String listId;

  const ShareScreen({required this.listId, Key? key}) : super(key: key);

  @override
  _ShareScreenState createState() => _ShareScreenState();
}

class _ShareScreenState extends State<ShareScreen> {
  final TextEditingController _emailController = TextEditingController();
  bool _isLoading = false;

  void _shareList() async {
    setState(() {
      _isLoading = true;
    });

    try {
      await Provider.of<ShoppingListProvider>(context, listen: false)
          .shareListWithUserByEmail(widget.listId, _emailController.text);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('List shared successfully')));
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Failed to share list')));
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Share List'),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                children: [
                  TextField(
                    controller: _emailController,
                    decoration: const InputDecoration(
                      labelText: 'User Email',
                      hintText: 'Enter the email of the user to share with',
                    ),
                  ),
                  const SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: _shareList,
                    child: const Text('Share'),
                  ),
                ],
              ),
            ),
    );
  }
}
