// ignore_for_file: unused_local_variable

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class FirestoreService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  Future<void> updateNotificationSetting(String listId, bool isEnabled) async {
    User? user = _auth.currentUser;
    if (user == null) {
      throw Exception('User not authenticated');
    }

    String userId = user.uid;

    DocumentReference listRef = _firestore.collection('shoppingLists').doc(listId);

    DocumentSnapshot listSnapshot = await listRef.get();

    if (!listSnapshot.exists) {
      throw Exception('List does not exist');
    }

    Map<String, dynamic> listData = listSnapshot.data() as Map<String, dynamic>;

    if (listData['owner'] == userId) {
      // Update owner's notification setting
      await listRef.update({
        'ownerNotificationsEnabled': isEnabled,
      });
    } else if (listData['sharedWith'] != null && listData['sharedWith'].contains(userId)) {
      // Update shared user's notification setting
      await listRef.update({
        'sharedWith.$userId': isEnabled,
      });
    } else {
      throw Exception('User does not have permission to update this setting');
    }
  }

  Future<void> shareListWithUser(String listId, String userEmail) async {
    User? user = _auth.currentUser;
    if (user == null) {
      throw Exception('User not authenticated');
    }

    DocumentReference listRef = _firestore.collection('shoppingLists').doc(listId);
    QuerySnapshot userSnapshot = await _firestore.collection('users').where('email', isEqualTo: userEmail).limit(1).get();

    if (userSnapshot.docs.isEmpty) {
      throw Exception('User with email $userEmail not found');
    }

    DocumentReference userRef = userSnapshot.docs.first.reference;

    await _firestore.runTransaction((transaction) async {
      DocumentSnapshot listSnapshot = await transaction.get(listRef);

      if (!listSnapshot.exists) {
        throw Exception('List does not exist');
      }

      Map<String, dynamic> listData = listSnapshot.data() as Map<String, dynamic>;

      if (listData['owner'] != user.uid) {
        throw Exception('Only the owner can share this list');
      }

      transaction.update(listRef, {
        'sharedWith.${userSnapshot.docs.first.id}': true,
      });
    });
  }

  Future<void> unshareListWithUser(String listId, String userId) async {
    User? user = _auth.currentUser;
    if (user == null) {
      throw Exception('User not authenticated');
    }

    DocumentReference listRef = _firestore.collection('shoppingLists').doc(listId);

    await _firestore.runTransaction((transaction) async {
      DocumentSnapshot listSnapshot = await transaction.get(listRef);

      if (!listSnapshot.exists) {
        throw Exception('List does not exist');
      }

      Map<String, dynamic> listData = listSnapshot.data() as Map<String, dynamic>;

      if (listData['owner'] != user.uid) {
        throw Exception('Only the owner can unshare this list');
      }

      transaction.update(listRef, {
        'sharedWith.$userId': FieldValue.delete(),
      });
    });
  }

  Future<List<String>> getSharedUsers(String listId) async {
    DocumentSnapshot listSnapshot = await _firestore.collection('shoppingLists').doc(listId).get();

    if (!listSnapshot.exists) {
      throw Exception('List does not exist');
    }

    Map<String, dynamic> listData = listSnapshot.data() as Map<String, dynamic>;

    if (listData['sharedWith'] != null) {
      return List<String>.from(listData['sharedWith'].keys);
    } else {
      return [];
    }
  }
}
