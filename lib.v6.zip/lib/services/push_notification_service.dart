// ignore_for_file: unused_import, depend_on_referenced_packages, unused_local_variable, duplicate_import, avoid_print

import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter_app_info/flutter_app_info.dart';
import 'package:http/http.dart' as http;
import 'package:googleapis_auth/auth_io.dart' as auth;
import 'package:googleapis/servicecontrol/v1.dart' as servicecontrol;
import 'package:provider/provider.dart';
import 'package:rxdart/rxdart.dart';

import 'dart:convert';
import 'package:http/http.dart' as http;

class PushNotificationService {
  static Future<String> getAccessToken() async {
    final serviceAccountJson = {
      "type": "service_account",
      "project_id": "handlenoe",
      "private_key_id": "3663e2d26761b4281ee9d22b114f7d6803e850c7",
      "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvAIBADANBgkqhkiG9w0BAQEFAASCBKYwggSiAgEAAoIBAQDZcfbI0VZcDp83\nJV6sz3v6r1NGd/pnkRFsxMRzARlZ3Abb4Vmnq1C4zai3cdLygn1TQIcMsVJvIKb1\n/2jpzbVK121Tt3lwdtz/3gRe72Z4XQYq9pfjzglFcZn6dbZ7oqOsHgMRSz/aJLgv\nKryRnsWOI0RtpowoNIsL04frMc7UmfHoZFTY5YSvq9yS4oLxyOPFVWNyTGtOcTTH\ndHgJZv+VFkWdtYA7rXE/zAsmjYQ+PWxZP9Drg0mESN3icoxXP6e88UgoA/CulkO6\nnS6R94ZMy1RyMIliKUeDUKWE4JvO/HnMBVeq1cc3KTqD7DGPKZaZSmJm+duiKX4B\nAjHeohUnAgMBAAECggEALRC7+1G7arfTEpxJm1ojEUjt4uBxwq4jpN3A8y7KoL+D\nomV5bdEJGUvySBash/s4Wx04AA7uDT8Aq2IkTbSG+rxcGaogXokb82GBmWVXYOGy\nqgvSXfGxJTXOmkR0Lfp+nmjX7OkiEiVjEM90Jl/4BKXVhD4stRZyrOBJvppjidb+\nI28basJy++b2g+Te6klyW0SnBlIm5AOgiTgETHR9Y/2Gvvepn2GGodvLA2QBLJQr\nY4oWpV1NlS2Pv4aqs/O+hatfaB2zQhQZn/tuZ2Idjm3T3YH2kK+ggOHqX6+53Sng\nL7f51wPbyapUlwNkkY5HPUVygH1GqonlVGCKEDWovQKBgQDxizG6LG9P8/Y0v2R7\n49voIjTwv2TAm0lZqBSUIoV54XxOTJIlWxILd8/xnArtDS04StS26gQijuyrdQ/j\n5Wed3IHX/z56yiVgTDqp0kE7hgYAbZtfdc4XeRrdKrhYGOk0eHKbFhZQU1qg6CEp\nHjy0VaUHHu4OqKyIuP5t7GzhIwKBgQDmdYtceBYWTmmMvpxxKhio9RYOsWmjGd3I\ngPx6L2lEVBKw66w8PU6aH6gY/bKwXH3VAy998nUFwihNDrvBrfz4psXCcIEEZSoh\nR1TH2bi+UmqNPizgqyYPxbWYElhpA1i/HnnWblKtwVxIjn8OV2iHdtBrKXEFD0P7\n2Di4KVyWLQKBgAQ0jTAVl/aHY9D1SBWUGP8IoW1Tl7h2u6cw8vLFSxedImHmmWDH\nHiBO/LLTKamI4jGps9xfZKUJYft2NUmdc9levm/5RKg0nsP3b8oHHBWiNraJMfxO\ne8ES3bHeDYmTHXRJaI1krAzH9rr4b6NcoGfvWcku86wTqbVTqzJUvGyLAoGAabHV\nNZaZwqc5v2QYScpdvveQozJ42WXekrudj8g4xi6s19luh74yU3tbVALetgXlbBFm\n8aOGShrO8vBj6iMK11tdbZy9fy+Kj/KwDmxrT1ZrKdYvLOcxsKAjddhMFfWD+TtX\n86FrZ+c7lMdNvF0YQrCaS9uYyxJCQrna4ZOOtA0CgYBN0jFMD7+Kp8vXIOsVWRiH\nsQ7tLoT025AhEBATTgr8c87FU0nc4qmgdkdgFgPP3lq2fwcOS6OYAI0lhvMvZr2X\nBshfXVicizZNVJV+hY7Z4xJSe04gpdWHzK7i3Dn9NyfypNpXwQhDfrYMonyZzoBI\nSpeTgq6gwraKx5CLhYs7xA==\n-----END PRIVATE KEY-----\n",
      "client_email": "handlenoe-project@handlenoe.iam.gserviceaccount.com",
      "client_id": "111823503943830431183",
      "auth_uri": "https://accounts.google.com/o/oauth2/auth",
      "token_uri": "https://oauth2.googleapis.com/token",
      "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
      "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/handlenoe-project@handlenoe.iam.gserviceaccount.com"
    };

    List<String> scopes = [
      "https://www.googleapis.com/auth/userinfo.email",
      "https://www.googleapis.com/auth/firebase.database",
      "https://www.googleapis.com/auth/firebase.messaging"
    ];

    var client = await auth.clientViaServiceAccount(
      auth.ServiceAccountCredentials.fromJson(serviceAccountJson),
      scopes,
    );

    var credentials = await auth.obtainAccessCredentialsViaServiceAccount(
      auth.ServiceAccountCredentials.fromJson(serviceAccountJson),
      scopes,
      client,
    );
    client.close();
    return credentials.accessToken.data;
  }

  static Future<void> sendNotificationToSelectedDriver(String deviceToken) async {
    final String serverKey = await getAccessToken();
    String endpointFirebaseCloudMessaging = 'https://fcm.googleapis.com/v1/projects/handlenoe/messages:send';

    final Map<String, dynamic> message = {
      'message': {
        'token': deviceToken,
        'notification': {
          'title': "NET TRIP REQUEST from me",
          'body': "PickUp Location: ayy \nDropOff Location: myy"
        }
      }
    };

    final http.Response response = await http.post(
      Uri.parse(endpointFirebaseCloudMessaging),
      headers: <String, String>{
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $serverKey',
      },
      body: jsonEncode(message),
    );

    if (response.statusCode == 200) {
      print('FCM message sent successfully');
      print('deviceToken: $deviceToken');
    } else {
      print('Failed to send FCM message: ${response.statusCode}');
      print('Error: ${response.body}');
    }
  }
}
