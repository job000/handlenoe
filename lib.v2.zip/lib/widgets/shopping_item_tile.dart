import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/shopping_item_model.dart';
import '../providers/auth_provider.dart';

class ShoppingItemTile extends StatelessWidget {
  final ShoppingItem item;
  final VoidCallback onTap;

  const ShoppingItemTile({
    required this.item,
    required this.onTap,
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ListTile(
      title: Text(item.name),
      trailing: Checkbox(
        value: item.isBought,
        onChanged: (bool? value) {
          onTap();
        },
      ),
      onLongPress: () {
        // Add logic to handle item deletion, only if the user is the creator
        final authProvider = Provider.of<AuthProvider>(context, listen: false);
        if (item.createdBy == authProvider.user?.uid) {
          // Logic to delete item
        }
      },
    );
  }
}
